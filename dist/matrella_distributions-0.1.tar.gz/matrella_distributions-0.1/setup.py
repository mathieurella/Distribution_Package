from setuptools import setup

setup(name='matrella_distributions',
      version='0.1',
      description='Gaussian & Binomial distributions',
      packages=['matrella_distributions'],
      author="Mathieu Rella",
      zip_safe=False)
